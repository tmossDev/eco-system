import type { Meta, StoryObj } from '@storybook/angular';
import { moduleMetadata } from '@storybook/angular';
import { ReactiveFormsModule, FormControl, Validators } from '@angular/forms';

import { DsCheckboxDirective } from './checkbox.directive';
import { DsFormField } from './form-field';
import { DsFormGroup } from './form-group';
import { DsInputDirective, DsSelectDirective } from './form-control.directive';

const meta: Meta = {
  title: 'Design System/Form',
  decorators: [
    moduleMetadata({
      imports: [
        ReactiveFormsModule,
        DsFormField,
        DsFormGroup,
        DsInputDirective,
        DsSelectDirective,
        DsCheckboxDirective,
      ],
    }),
    (story) => ({
      ...story(),
      template: `
        <div style="width: min(32rem, calc(100vw - 2rem));">
          ${story().template}
        </div>
      `,
    }),
  ],
  parameters: {
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj;

export const TextInput: Story = {
  render: () => ({
    template: `
      <ds-form-field label="Email address" hint="Use your work email." required>
        <input dsInput type="email" autocomplete="email" placeholder="you@example.com" />
      </ds-form-field>
    `,
  }),
};

export const WithError: Story = {
  render: () => ({
    props: {
      email: new FormControl('', {
        nonNullable: true,
        validators: [Validators.required, Validators.email],
      }),
    },
    template: `
      <ds-form-field label="Email address" error="Enter a valid email address." required>
        <input dsInput type="email" [formControl]="email" autocomplete="email" />
      </ds-form-field>
    `,
  }),
};

export const SelectAndTextarea: Story = {
  render: () => ({
    template: `
      <ds-form-group legend="Product details" description="Fields share the same accessible styling.">
        <ds-form-field label="Category">
          <select dsSelect>
            <option>Apparel</option>
            <option>Accessories</option>
            <option>Home</option>
          </select>
        </ds-form-field>

        <ds-form-field label="Description" hint="Keep it concise for storefront cards.">
          <textarea dsInput placeholder="Describe the product"></textarea>
        </ds-form-field>
      </ds-form-group>
    `,
  }),
};

export const Checkbox: Story = {
  render: () => ({
    template: `
      <ds-form-field label="Publish product" hint="Published products are visible in the storefront.">
        <input dsCheckbox type="checkbox" />
      </ds-form-field>
    `,
  }),
};
